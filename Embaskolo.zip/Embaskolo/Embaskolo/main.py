
import pygame as pg
import game
import gameplay_state
import main_menu
from constants import *

def main():
    pg.init()
    pg.display.set_caption("Embaskolo")
    screen = pg.display.set_mode(RES)

    states = {
        "GAMEPLAY": gameplay_state.GameplayState(screen),
        "MAIN_MENU": main_menu.MainMenu(screen),
    }

    embaskolo = game.Game(screen, states)
    embaskolo.main()

main()
