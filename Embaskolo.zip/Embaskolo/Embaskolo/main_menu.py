
import pygame as pg
from constants import *
from button import *

class MainMenu:
    def __init__(self, screen):
        self.buttons = []

        self.buttons.append(TextButton("Generate Level", 20, 20, 10, 5, (40, 40, 250), text_color=WHITE))
        self.buttons.append(TextButton("Select Level", 20, self.buttons[-1].pos.bottom + 10,
                                       10, 5, (40, 40, 250), text_color=WHITE))
        # self.buttons.append(TextButton("Hello world", 50, 50, 10, 5, LBLUE))
        # self.buttons.append(Button(50, 50, 100, 50, LBLUE))
        self.surface = screen
        self.next_state = "GAMEPLAY"
        self.running = True

    def startup(self):
        self.running = True

    def events(self, event):
        # for event in pg.event.get():
        if event.type == pg.QUIT:
            self.playing = False
        if event.type == pg.MOUSEBUTTONUP:
            for button in self.buttons:
                if button.is_down:
                    self.running = False
                    # print(button.text.text)
            # key = pg.key.get_pressed()
            # if key[pg.K_LEFT]:
                # self.buttons[0].move_left(1)
                # print("left")
            # if key[pg.K_RIGHT]:
                # self.buttons[0].move_right(1)
                # print("right")
            # if key[pg.K_UP]:
                # self.buttons[0].move_up(1)
                # print("up")
            # if key[pg.K_DOWN]:
                # self.buttons[0].move_down(1)
                # print("down")
            # if key[pg.K_p]:
                # self.buttons[0].press()
            # if not key[pg.K_p]:
                # self.buttons[0].release()

    def update(self):
            for button in self.buttons:
                button.update()

    def draw(self):
        self.surface.fill(WHITE)
        for button in self.buttons:
            button.draw(self.surface)

    # def main(self):
# 
        # while self.playing:
            # self.events()
            # self.draw()
