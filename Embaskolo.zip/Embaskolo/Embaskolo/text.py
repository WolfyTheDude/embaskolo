
from constants import *
import pygame as pg

class Text:
    def __init__(self, text, x=0, y=0, color=WHITE, shadow_color=DGRAY):
        self.font = pg.font.SysFont(None, 50)
        self.text = text # str.encode(text)

        size = self.font.size(text)
        self.pos = pg.Rect(x, y, size[0], size[1])
        self.shadow_pos = pg.Rect(x - SHADOW_SIZE, y + SHADOW_SIZE, size[0], size[1])

        self.color = color
        self.shadow_color = shadow_color

        self.rendered_text = self.font.render(str.encode(self.text), True, self.color)
        self.shadow = self.font.render(str.encode(self.text), True, self.shadow_color)
