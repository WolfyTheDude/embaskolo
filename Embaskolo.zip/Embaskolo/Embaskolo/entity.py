
import pygame as pg

class Entity:
    def __init__(self, x=0, y=0, width=32, height=32):
        self.pos = pg.Rect(x, y, width, height)
        self.xv = 0
        self.yv = 0
