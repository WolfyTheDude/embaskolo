
import random
from platform import *
from goal import *
import pygame as pg

class Level:
    def __init__(self, type="Goal"):
        self.goal = Goal(0, 0, 0, 0)
        self.platforms = []
        self.player_start_pos = pg.Rect(0, 0, 32, 32)
        self.size = [0, 0]

    def set_size(self):
        bottom = 0
        right = 0
        for platform in self.platforms:
            if platform.pos.x > right:
                right = platform.pos.right
            if platform.pos.y > bottom:
                bottom = platform.pos.bottom

        self.size = [right, bottom]

    def __getitem__(self, index):
        return self.platforms[index]
    
    def exit(self):
        self.platforms = []

    def update(self, stopwatch, player):
        self.goal.update(stopwatch, player)
        for i in self.platforms:
            if hasattr(i, "update"):
                i.update()

    # def reset(self, stopwatch, player):
    def reset(self):
        # stopwatch.start()
        self.goal.reset()
        # player.pos.x = self.player_start_pos.x
        # player.pos.y = self.player_start_pos.y
        # player.xv = 0
        # player.yv = 0

    def draw(self, surface, camera, light, dark_mode=False):

        # Draw platforms
        for i, platform in enumerate(self.platforms):
            if dark_mode: # If dark_mode then only draw platforms in the light
                if platform.pos.colliderect(light):
                    camera.draw_rect(surface, platform.color, platform.pos)
            else:
                camera.draw_rect(surface, platform.color, platform.pos)

        # Draw goal
        camera.draw_rect(surface, self.goal.color, self.goal.pos)
        

    def generate_level(self, size=(50, 50), freq=0.15):
        # self.size = size
        self.size[0] = size[0] * 32
        self.size[1] = size[1] * 32
        self.platforms = []
        width = 32 # 32 + 96 + 32 # + 32 + 64 # sizes[random.randint(0, len(sizes) - 1)] # random.random() * 128
        height = 32 # sizes[random.randint(0, len(sizes) - 1)] # random.random() * 128

        for i in range(size[0]):
            for j in range(size[1]):
                width = random.randint(2, 4) * 32 # width_variance[random.randint(0, len(width_variance) - 1)]
                if random.random() < freq:
                    self.platforms.append(Platform(j * 32, i * 32, width, height)) # j * 1?

        self.goal = Goal(self.platforms[-1].pos.x, self.platforms[-1].pos.y - height)

        # new_platforms will replace self.platforms
        # but it will not contain any platforms that are touching the goal
        # (making the goal unaccessable)
        new_platforms = [] # [platform for platform in self.platforms if not self.goal.pos.colliderect(platform.pos)]

        for i, platform in enumerate(self.platforms):
            if not self.goal.pos.colliderect(platform.pos):
                new_platforms.append(platform)

        self.platforms = new_platforms
        self.goal.correct_pos()

    def read_level_basic(self, player, name):
        self.platforms = []
        # Width and height for platforms/blocks
        width = 32
        height = 32
        if name == "original1":
            # First level ever
            self.platforms = [Platform(i * 32, 200) for i in range(1, 10)]
        if name == "original2":
            # Second level ever
            self.platforms.append(Platform(100, 300, 200))
            self.platforms.append(Platform(-1 + -500, 400 + 32, 642 + 1000, 2)) # bottom line
            self.platforms.append(Platform(500, 200))
            self.platforms.append(Platform(10, 200))
            self.platforms.append(Platform(50, 50, 200))
            self.platforms.append(Platform(400, 75, 100))
            self.platforms.append(Platform(295, 200, 50))
            self.platforms.append(Platform(640 - 5, 32, 5, 300)) # wall on far right
            self.platforms.append(Platform(500, 32 + 43, 5, 300 - 32)) # wall on far right counterpart

            self.platforms.append(Platform(608, 400, up=True))
            self.platforms.append(Platform(500, 400, 200, moves=True))
            return self.platforms

        try:
            self.platforms_file = open(name, "r")
        except FileNotFoundError:
            return

        up = True
        color = 50
        for i, line in enumerate(self.platforms_file):
            for j, char in enumerate(line):
                if char == "b": # B for block
                    self.platforms.append(Platform(j * width, i * height, width, height, color))
                elif char == "g":
                    self.goal = Goal((j * width) + width / 4,
                                      (i * height) + height / 4,
                                      width / 2, height / 2)
                elif char == "p": # P for platform
                    self.player_start_pos = pg.Rect(j * width, i * height, 32, 32)
                    # player.pos.x = j * width
                    # player.pos.y = i * height
                    # self.platforms.append(Platform(j * width, i * height, width * 3, height))

            if color > 200:
                up = False
            if color < 50:
                up = True
            color += 10 if up else -10

        self.set_size()

