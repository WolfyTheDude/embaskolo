
import pygame as pg
from player import *
from camera import *
from constants import *
from platform import *
from stopwatch import *
from goal import *
from level import *
from menu import Menu

class GameplayState:

    def __init__(self, screen):
        self.font = pg.font.SysFont(None, 21)
        self.player = Player()
        self.camera = Camera()
        self.stopwatch = StopWatch()
        self.level = Level()
        self.running = True
        self.surface = screen
        self.next_state = "MAIN_MENU"
        self.light = pg.Rect(0, 0, 256, 256)
        self.dark_mode = False
        self.hide_debug = False
        self.level.generate_level()

    def startup(self):
        self.running = True
        self.level.generate_level()
        self.reset()

    def debug_text(self, content, hide=False, *args):
        """
        Blits debug text to surface that is given line by line.

        Arguments:
        content: dict, each key/value pair will be put on a line.
        Can put lists/tuples as dict value, they will simply be comma separated.
        
        hide: Boolean, if true this text will not display

        *args: Aything else will be converted to a string and put on its own line
        Lists and tuples will have all of their elements comma separated in the line.
        """

        if hide: return

        # Position of text
        x = 5
        y = 5

        # Takes set (list, tuple, etc) and combines each element with a comma
        combine = lambda x: ", ".join([str(i) for i in x]) \
            if hasattr(type(x), "__getitem__") else str(x)
            # if type(x) is list or type(x) is tuple else str(x)

        # Goes through dict
        for key in list(content.keys()):
            line = key + ": " + combine(content[key])
            rendered_text = self.font.render(str.encode(line), True, WHITE, GRAY)
            self.surface.blit(rendered_text, (x, y))
            y += 15 # 18

        # Any other arguments will be converted to string
        # List/tuples will be comma separated
        for item in args:
            line = combine(item)
            rendered_text = self.font.render(str.encode(line), True, WHITE, GRAY)
            self.surface.blit(rendered_text, (x, y))
            y += 15 # 18

    def reset(self):
        self.stopwatch.start()
        # self.goal.reset()
        self.level.reset()
        self.player.pos.x = self.level.player_start_pos.x
        self.player.pos.y = self.level.player_start_pos.y
        self.player.xv = 0
        self.player.yv = 0

    def load_level(self, name):
            self.level.read_level_basic(self.player, name)
            self.player.pos.x = self.level.player_start_pos.x
            self.player.pos.y = self.level.player_start_pos.y

    def events(self, event):
        world_size = 50
        block_freq = .05
        key = pg.key.get_pressed()
        if event.type == pg.KEYDOWN:
        # if key[pg.K_q]:
            if event.key == pg.K_q:
                self.running = False
            # self.next_state = "MAIN_MENU"
        if key[pg.K_f]:
            self.level.generate_level() # (world_size, world_size), block_freq)
            self.reset()
        if key[pg.K_l]:
            hide_debug ^= 1
        if key[pg.K_p]:
            self.dark_mode ^= 1
        if key[pg.K_r]:
            self.reset()

        if key[pg.K_1]:
            self.load_level("original1")
        if key[pg.K_2]:
            self.load_level("original2")
        if key[pg.K_3]:
            self.load_level("level1")
        if key[pg.K_4]:
            self.load_level("level2")

        if key[pg.K_c]:
            self.player.pos.x = 40 * 32
            self.player.pos.y = 40 * 32

        if key[pg.K_v]:
            self.level.check_goal()

        # if key[pg.K_g]:
            # self.camera.zoom = 2
            # for i, block in enumerate(self.level):
                # self.level[i].pos.w *= self.camera.zoom
                # self.level[i].pos.h *= self.camera.zoom
            # self.player.pos.w *= self.camera.zoom
            # self.player.pos.h *= self.camera.zoom
        # if key[pg.K_h]:
            # self.camera.zoom = .5
            # for i, block in enumerate(self.level):
                # self.level[i].pos.w *= self.camera.zoom
                # self.level[i].pos.h *= self.camera.zoom
            # self.player.pos.w *= self.camera.zoom
            # self.player.pos.h *= self.camera.zoom

    def draw(self):
        # Note that the goal will be drawn regardless of light
        if self.dark_mode:
            self.surface.fill(BLACK)
        else:
            self.surface.fill(WHITE)
        self.level.draw(self.surface, self.camera, self.light, self.dark_mode) # Draw level
        self.camera.draw_rect(self.surface, self.player.color, self.player.pos) # Draw player
        self.debug_text({"Timer": self.stopwatch.get_time(),
                            # "Level": touching_platform,
                            "On Right Wall": self.player.on_right_wall,
                            "On Left Wall": self.player.on_left_wall})
        # self.debug_text({"World Size (U & I to change)": world_size,
                            # "Platform Frequency (J & K to change, higher means more platforms)": "%0.3f" % block_freq},
                        # hide_debug,
                        # ["R to reset position", "F to generate new level with the given world size/platform frequency"],
                        # ["Z & X change size", "G & H experimental", "L to toggle this text"])

    def update(self):
        self.camera.update(self.player, self.level) # Update camera
        self.player.update(self.level, self.camera) # Update player
        # Have light center on player
        self.light.centerx = self.player.pos.centerx
        self.light.centery = self.player.pos.centery

        self.level.update(self.stopwatch, self.player) # Update level
