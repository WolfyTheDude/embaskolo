
from constants import *
import pygame as pg

class Game:
    def __init__(self, screen, states):
        self.screen = screen
        self.states = states
        self.clock = pg.time.Clock()
        self.state = self.states["GAMEPLAY"]
        self.running = True

    def switch_state(self):
        if self.state.next_state == "QUIT":
            self.running = False
        else:
            self.state = self.states[self.state.next_state]
            self.state.startup()

    def events(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.running = False
            self.state.events(event)

    def update(self):
        self.state.update()
    def draw(self):
        self.state.draw()
    def main(self):
        while self.running:
            if not self.state.running:
                self.switch_state()
            self.events()
            self.update()
            self.draw()
            pg.display.flip()
            self.clock.tick(FPS)
