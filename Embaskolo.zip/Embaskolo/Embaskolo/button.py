
from constants import *
from text import *
import pygame as pg

class Button:
    def __init__(self, x=0, y=0, width=100, height=100, color=LBLUE, shadow_color=DGRAY):
        self.is_down = False

        # Rects
        self.pos = pg.Rect(x, y, width, height)
        self.color_pos = pg.Rect(x + SHADOW_SIZE, y, width - SHADOW_SIZE, height - SHADOW_SIZE)
        self.shadow_pos = pg.Rect(x, y + SHADOW_SIZE, width - SHADOW_SIZE, height - SHADOW_SIZE)
        self.layers = [self.shadow_pos, self.color_pos, self.pos]

        # Colors
        self.color = color
        self.shadow_color = shadow_color


    def press(self):
        if not self.is_down:
            for layer in self.layers[1:]:
                layer.x -= SHADOW_SIZE
                layer.y += SHADOW_SIZE
            self.is_down = True

    def release(self):
        if self.is_down:
            for layer in self.layers[1:]:
                layer.x += SHADOW_SIZE
                layer.y -= SHADOW_SIZE
            self.is_down = False

    def move_right(self, amount):
        for layer in self.layers:
            layer.x += amount

    def move_left(self, amount):
        for layer in self.layers:
            layer.x -= amount

    def move_up(self, amount):
        for layer in self.layers:
            layer.y -= amount

    def move_down(self, amount):
        for layer in self.layers:
            layer.y += amount

    def draw(self, surface):
        pg.draw.rect(surface, self.shadow_color, self.shadow_pos) # Shadow of button
        pg.draw.rect(surface, self.color, self.color_pos) # Main part of button


class TextButton(Button):
    def __init__(self, text, x=0, y=0, xmargin=10, ymargin=5,
                 color=LGRAY, text_color=WHITE,
                 shadow_color=DGRAY, text_shadow_color=DGRAY):

        self.next_state = "GAMEPLAY"
        self.text = Text(text, x + xmargin + SHADOW_SIZE, y + ymargin,
                         text_color, text_shadow_color)
        super().__init__(x, y,
                         self.text.pos.width + xmargin * 2,
                         self.text.pos.height + ymargin * 2,
                         color, shadow_color)

        self.layers.append(self.text.pos)
        self.layers.append(self.text.shadow_pos)

    def update(self):
        if self.pos.collidepoint(pg.mouse.get_pos()):
            self.press()
        else:
            self.release()

    def draw(self, surface):
        pg.draw.rect(surface, self.shadow_color, self.shadow_pos) # Overall shadow
        pg.draw.rect(surface, self.color, self.color_pos) # Box around text
        surface.blit(self.text.shadow, self.text.shadow_pos) # Text shadow
        surface.blit(self.text.rendered_text, self.text.pos) # Text
