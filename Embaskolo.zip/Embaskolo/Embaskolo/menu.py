
import pygame as pg

class Menu:
    def __init__(self):
        self.buttons = []
        # self.surface = pg.display.set_mode((200, 100))

    def open(self):
        pass
