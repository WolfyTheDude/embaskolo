
class MenuState:
    def events(self):
        pass
